
Simple ChatBot (Python)

How to run:
1. Make sure Python is installed.
2. Open terminal in this folder.
3. Run: python chatbot.py

Commands:
- hello / hi
- name
- help
- exit
