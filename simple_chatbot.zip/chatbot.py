
def chatbot():
    print("Simple ChatBot 🤖")
    print("Type 'exit' to quit.")

    while True:
        user_input = input("You: ").lower()

        if user_input == "exit":
            print("Bot: Bye! Have a great day 🙂")
            break
        elif "hello" in user_input or "hi" in user_input:
            print("Bot: Hello! How can I help you?")
        elif "name" in user_input:
            print("Bot: I am a simple Python chatbot.")
        elif "help" in user_input:
            print("Bot: You can say hello, ask my name, or type exit.")
        else:
            print("Bot: Sorry, I don't understand that yet.")

if __name__ == "__main__":
    chatbot()
